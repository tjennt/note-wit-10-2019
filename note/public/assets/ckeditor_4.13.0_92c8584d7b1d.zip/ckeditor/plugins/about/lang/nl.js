﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'nl', {
	copy: 'Copyright &copy; $1. Alle rechten voorbehouden.',
	dlgTitle: 'Over CKEditor 4',
	moreInfo: 'Bezoek onze website voor licentieinformatie:'
} );
