﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'pastefromword', 'ro', {
	confirmCleanup: 'Textul pe care doriți să-l lipiți este din Word. Doriți curățarea textului înante de a-l adăuga?',
	error: 'Nu a fost posibilă curățarea datelor adăugate datorită unei erori interne',
	title: 'Adaugă din Word',
	toolbar: 'Adaugă din Word'
} );
